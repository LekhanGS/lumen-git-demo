import packages.*;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Menu open = new Menu();
        open.start();
    }
}